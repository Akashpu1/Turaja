<body class="template-color-1" style="zoom: 1;">
<div class="main-wrapper">


    <!-- <header> -->
    <!-- Begin Main Header Area -->
<!-- Begin Main Header Area Two -->
<header class="main-header_area-2">
  <div class="header-top_area d-none d-lg-block">
    <div class="container">
      <div class="header-top_nav">
        <div class="row">
          <div class="col-lg-12">
            <div class="ht-menu text-center">
                          Free Domestic Shipping
                         </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="header-middle_area">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="header-middle_nav">
            <div class="header-logo_area">
              <a href="http://localhost/tcom/">
                <img src="http://localhost/tcom/assets/images/menu/logo/1.png" alt="Header Logo">
              </a>
            </div>


            <div class="header-right_area  header-right_area-2">

              <ul>
                <li class="mobile-menu_wrap d-lg-none">
                  <a href="#mobileMenu" class="mobile-menu_btn toolbar-btn color--white">
                    <i class="ion-android-menu"></i>
                  </a>
                </li>
                <li>
                  <a href="http://localhost/tcom/auth" class="menu-btn  color--white  d-lg-block">

                    <i class="ion-android-person"></i>

                  </a>
                </li>

                <li class="minicart-wrap">
                  <a href="#miniCart" class="minicart-btn toolbar-btn">
                    <div class="minicart-count_area">
                      <span class="item-count card-item-count">1</span>
                      <i class="ion-bag"></i>
                    </div>
                  </a>
                </li>


              </ul>
              <div class="currency-switcher">
                <div class="form-currency">
                  <select id="myselect">
                    <option value="INR">
                      INR
                    </option>
                    <option value="USD">
                      USD
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="header-bottom_area d-none d-lg-block">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="main-menu_area position-relative">
            <nav class="main-nav d-flex justify-content-center">
              <ul>
                <li><a href="http://localhost/tcom/shop?cat=newarrival">New Arrival</a></li>
                <li><a href="http://localhost/tcom/shop?cat=Sarees">Saree <i class="ion-chevron-down"></i></a>
                  <ul class="kenne-dropdown">
                    <li><a href="http://localhost/tcom/shop?cat=sareetussar">Tussar</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=ChanderiSarees">Chanderi</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=Crape">Crape</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=Chiffon">Chiffon</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=Georget">Georget</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=Linen">Linen</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=Silk">Silk</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=Orgenza">Orgenza</a></li>
                  </ul>
                </li>
                <li><a href="http://localhost/tcom/'shop?cat=16'">Suits
                    <i class="ion-chevron-down"></i></a>
                  <ul class="kenne-dropdown">
                    <li><a href="http://localhost/tcom/shop?cat=suittussar">Tussar</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=ChanderiSuits">Chanderi</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=Fancybangloreitem">Fancy banglore item</a></li>
                  </ul>

                </li>
                <li><a href="http://localhost/tcom/shop?cat=13">Dupatta</a></li>
                <li><a href="http://localhost/tcom/shop?cat=15">Ready To Wear
                    <i class="ion-chevron-down"></i></a>
                  <ul class="kenne-dropdown">
                    <li><a href="http://localhost/tcom/shop?cat=Chanderireadytowear">Chanderi</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=15tussar">Tussar</a></li>
                  </ul>

                </li>


                <li><a href="http://localhost/tcom/shop?cat=17">Men's <i class="ion-chevron-down"></i></a>
                  <ul class="kenne-dropdown">
                    <li><a href="http://localhost/tcom/shop?cat=Kurta">Kurta</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=Jacket">Jacket</a></li>
                  </ul>
                </li>

                <li><a href="http://localhost/tcom/shop?cat=14">Fabric </a>
                </li>

                <li><a href="http://localhost/tcom/shop?cat=18">Accessories
                    <i class="ion-chevron-down"></i></a>
                  <ul class="kenne-dropdown">
                    <li><a href="http://localhost/tcom/shop?cat=18">Men's</a></li>
                    <li><a href="http://localhost/tcom/shop?cat=18">Woman's</a></li>

                  </ul>

                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="header-sticky sticky">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <div class="sticky-header_nav position-relative">
            <div class="row align-items-center justify-content-between">
              <div class="col-lg-2 col-sm-6">
                <div class="header-logo_area">
                  <a href="http://localhost/tcom/">
                    <img src="http://localhost/tcom/assets/images/menu/logo/1.png" alt="Header Logo">
                  </a>
                </div>
              </div>
              <div class="col-lg-8 d-none d-lg-block position-static">
                <div class="main-menu_area">
                  <nav class="main-nav d-flex justify-content-center">
                    <ul>
                      <li><a href="http://localhost/tcom/shop?cat=newarrival">New Arrival</a></li>
                      <li><a href="http://localhost/tcom/shop?cat=Sarees">Saree <i class="ion-chevron-down"></i></a>
                        <ul class="kenne-dropdown">
                          <li><a href="http://localhost/tcom/shop?cat=sareetussar">Tussar</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Chanderi">Chanderi</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Crape">Crape</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Chiffon">Chiffon</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Georget">Georget</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Linen">Linen</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Silk">Silk</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Orgenza">Orgenza</a></li>
                        </ul>
                      </li>
                      <li><a href="http://localhost/tcom/'shop?cat=16'">Suits
                          <i class="ion-chevron-down"></i></a>
                        <ul class="kenne-dropdown">
                          <li><a href="http://localhost/tcom/shop?cat=suittussar">Tussar</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Chanderi">Chanderi</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Fancybangloreitem">Fancy banglore item</a></li>
                        </ul>

                      </li>
                      <li><a href="http://localhost/tcom/shop?cat=13">Dupatta</a></li>
                      <li><a href="http://localhost/tcom/shop?cat=15">Ready To Wear
                          <i class="ion-chevron-down"></i></a>
                        <ul class="kenne-dropdown">
                          <li><a href="http://localhost/tcom/shop?cat=suittussar">Chanderi</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=15tussar">Tussar</a></li>

                        </ul>

                      </li>


                      <li><a href="http://localhost/tcom/shop?cat=17">Men's <i class="ion-chevron-down"></i></a>
                        <ul class="kenne-dropdown">
                          <li><a href="http://localhost/tcom/shop?cat=Kurta">Kurta</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=Jacket">Jacket</a></li>
                        </ul>
                      </li>

                      <li><a href="http://localhost/tcom/shop?cat=14">Fabric </a>
                      </li>

                      <li><a href="http://localhost/tcom/shop?cat=18">Accessories
                          <i class="ion-chevron-down"></i></a>
                        <ul class="kenne-dropdown">
                          <li><a href="http://localhost/tcom/shop?cat=18">Men's</a></li>
                          <li><a href="http://localhost/tcom/shop?cat=18">Woman's</a></li>

                        </ul>

                      </li>
                    </ul>
                  </nav>
                </div>
              </div>
              <div class="col-lg-2 col-sm-6">
                <div class="header-right_area header-right_area-2">
                  <ul>
                    <li class="mobile-menu_wrap d-lg-none">
                      <a href="#mobileMenu" class="mobile-menu_btn toolbar-btn color--white">
                        <i class="ion-android-menu"></i>
                      </a>
                    </li>
                    <li>
                      <a href="#offcanvasMenu" class="menu-btn toolbar-btn color--white  d-lg-block">

                        <i class="ion-android-person"></i>

                      </a>
                    </li>

                    <li class="minicart-wrap">
                      <a href="#miniCart" class="minicart-btn toolbar-btn">
                        <div class="minicart-count_area">
                          <span class="item-count card-item-count">1</span>
                          <i class="ion-bag"></i>
                        </div>
                      </a>
                    </li>


                  </ul>
                  <div class="currency-switcher">
                    <div class="form-currency">
                      <select onchange="setLocation(this.value)" id="myselect">
                        <option>
                          INR

                        </option>
                        <option>
                          USD

                        </option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="offcanvas-minicart_wrapper" id="miniCart"><div class="offcanvas-menu-inner">
  <a class="btn-close"><i class="ion-android-close"></i></a>
      <div class="minicart-content">
      <div class="minicart-heading">
        <h4>Shopping Cart</h4>
      </div>
      <ul class="minicart-list">
                
          <li class="minicart-product">
            <a class="product-item_remove card-item-remove" data-id="115f89503138416a242f40fb7d7f338e" href="javascript:void(0)"><i class="ion-android-close"></i></a>
            <div class="product-item_img">
              <img src="http://localhost/tcom/uploads/product/zafar_azar_shirt_011.jpg" alt="Zafar Azar Shirt Product Image">
            </div>
            <div class="product-item_content">
              <a class="product-item_title" href="shop-left-sidebar.html">Zafar Azar Shirt</a>
                            <span class="product-item_quantity">1(Quantity) x 1000</span>
                              <span class="product-item_quantity">Size : S </span>
                          </div>
          </li>
              </ul>
    </div>
    <div class="minicart-item_total">
      <span>Subtotal</span>
      <span class="ammount">Rs. 1,000.00</span>
    </div>

    <div class="minicart-btn_area">
      <a href="http://localhost/tcom/checkout" class="kenne-btn kenne-btn_fullwidth">Checkout</a>
    </div>
  </div>

<script type="text/javascript">
  $('.card-item-remove').on('click', function() {
    var pid = $(this).attr('data-id');
    $.ajax({
      url: "http://localhost/tcom/web/collection/removetocard",
      method: "POST",
      data: {
        pid: pid
      },
      success: function(data) {
        if (data) {
          location.reload();
        }
      }
    });
  });

  $('.btn-close').on('click', function() {
    $('#miniCart').removeClass("open");
  });
</script></div>
  <div class="mobile-menu_wrapper" id="mobileMenu">
    <div class="offcanvas-menu-inner">
      <div class="container">
        <a href="#" class="btn-close white-close_btn"><i class="ion-android-close"></i></a>
        <div class="offcanvas-inner_logo">
          <a href="http://localhost/tcom/">
            <img src="http://localhost/tcom/assets/images/menu/logo/1.png" alt="Header Logo">
          </a>
        </div>
        <nav class="offcanvas-navigation">
          <ul class="mobile-menu">
            <li>
              <a href="#">
                <span class="mm-text">NEW ARRIVAL</span>
              </a>
            </li>
            <li class="menu-item-has-children active"><span class="menu-expand"><i class="ion-ios-plus-empty"></i></span><a href="#"><span class="mm-text">SAREE</span></a>
              <ul class="sub-menu" style="display: none;">
                <li><a href="#">Tussar</a></li>
                <li><a href="#">Chanderi</a></li>
                <li><a href="#">Crape</a></li>
                <li><a href="#">Chiffon</a></li>
                <li><a href="#">Georget</a></li>
                <li><a href="#">Linen</a></li>
                <li><a href="#">Silk</a></li>
                <li><a href="#">Orgenza</a></li>
              </ul>
            </li>

            <li class="menu-item-has-children"><span class="menu-expand"><i class="ion-ios-plus-empty"></i></span>
              <a href="#">
                <span class="mm-text">SUITS</span>
              </a>
              <ul class="sub-menu" style="display: none;">


                <li><a href="#">Tussar</a></li>
                <li><a href="#">Chanderi</a></li>
                <li><a href="#">Fancy banglore item</a></li>

              </ul>
            </li>
            <li class="">
              <a href="#">
                <span class="mm-text"> DUPATTA</span>
              </a>
            </li>

            <li class="menu-item-has-children"><span class="menu-expand"><i class="ion-ios-plus-empty"></i></span>
              <a href="#">
                <span class="mm-text">READY TO WEAR</span>
              </a>
              <ul class="sub-menu" style="display: none;">
                <li><a href="#">Chanderi</a></li>
                <li><a href="#">Tussar</a></li>

              </ul>
            </li>

            <li class="menu-item-has-children"><span class="menu-expand"><i class="ion-ios-plus-empty"></i></span>
              <a href="#">
                <span class="mm-text">MES'S</span>
              </a>
              <ul class="sub-menu" style="display: none;">
                <li><a href="#">Kurta</a></li>
                <li><a href="#">Jacket</a></li>

              </ul>
            </li>

            <li>
              <a href="#">
                <span class="mm-text">FABRIC</span>
              </a>

            </li>

            <li class="menu-item-has-children"><span class="menu-expand"><i class="ion-ios-plus-empty"></i></span>
              <a href="#">
                <span class="mm-text">ACCESSORIES</span>
              </a>
              <ul class="sub-menu" style="display: none;">
                <li><a href="#">Men's</a></li>
                <li><a href="#">Woman's</a></li>

              </ul>
            </li>
          </ul>
        </nav>
        <nav class="offcanvas-navigation user-setting_area">
          <ul class="mobile-menu">
            <li class="menu-item-has-children active"><span class="menu-expand"><i class="ion-ios-plus-empty"></i></span>
              <a href="#">
                <span class="mm-text">User
                  Setting
                </span>
              </a>
              <ul class="sub-menu" style="display: none;">
                <li>
                  <a href="my-account.html">
                    <span class="mm-text">My Account</span>
                  </a>
                </li>

              </ul>
            </li>


          </ul>
        </nav>
      </div>
    </div>
  </div>
  <div class="global-overlay"></div>
</header>
<!-- Main Header Area End Here Two -->
<!-- Main Header Area End Here -->
    <!-- </header> -->
    

    <!-- <main> -->
    <style>
  .select2-container--default .select2-selection--single {

    background: #ffffff;
    border: 1px solid #e5e5e5;
    border-radius: 0;
    height: 42px;
    width: 100%;
    padding: 0 0 0 10px;
  }



  .select2-container--default .select2-selection--single .select2-selection__arrow {
    top: 8px;
  }
</style>
<div class="checkout-area">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="coupon-accordion">
                      <h3>Returning customer? <span id="showlogin">Click here to login</span></h3>
            <div id="checkout-login" class="coupon-content">
              <div class="coupon-info">

                <form action="javascript:void(0)">
                  <p class="form-row-first">
                    <label>Username or email <span class="required">*</span></label>
                    <input type="text">
                  </p>
                  <p class="form-row-last">
                    <label>Password <span class="required">*</span></label>
                    <input type="text">
                  </p>
                  <p class="form-row">
                    <input value="Login" type="submit">
                    <label>
                      <input type="checkbox">
                      Remember me
                    </label>
                  </p>
                  <p class="lost-password"><a href="javascript:void(0)">Lost your password?</a></p>
                </form>
              </div>
            </div>
                    <h3>Have a coupon? <span id="showcoupon">Click here to enter your code</span></h3>
          <div id="checkout_coupon" class="coupon-checkout-content">
            <div class="coupon-info">
              <form action="javascript:void(0)">
                <p class="checkout-coupon">
                  <input placeholder="Coupon code" type="text">
                  <input class="coupon-inner_btn" value="Apply Coupon" type="submit">
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <form action="http://localhost/tcom/gopayment" method="post">
      <div class="row">
        <div class="col-lg-6 col-12">
          <div class="checkbox-form">
            <h3>Billing Details</h3>
                          <div class="row">
                <div class="col-md-6">
                  <div class="checkout-form-list">
                    <label>First Name <span class="required">*</span></label>
                    <input placeholder="" type="text" name="first_name" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="checkout-form-list">
                    <label>Last Name <span class="required">*</span></label>
                    <input placeholder="" type="text" name="last_name" required>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="checkout-form-list">
                    <label>Email Address <span class="required">*</span></label>
                    <input placeholder="" type="email" name="email" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="checkout-form-list">
                    <label>Phone <span class="required">*</span></label>
                    <input type="text" name="phone" required>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="checkout-form-list">
                    <label>Address <span class="required">*</span></label>
                    <input placeholder="Street address" type="text" name="address" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="checkout-form-list">
                    <input placeholder="Apartment, suite, unit etc. (optional)" name="street" type="text" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="checkout-form-list">
                    <label>Town / City <span class="required">*</span></label>
                    <select class="form-control cities select2-hidden-accessible" name="city" required tabindex="-1" aria-hidden="true">
                      <option selected="">Select City</option>
                    <option value="Farrukhnagar">Farrukhnagar</option></select><span class="select2 select2-container select2-container--default select2-container--below" dir="ltr" style="width: 570px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-city-yj-container"><span class="select2-selection__rendered" id="select2-city-yj-container" title="Farrukhnagar">Farrukhnagar</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="checkout-form-list">
                    <label>State<span class="required">*</span></label>
                    <select id="states" class="form-control select2-hidden-accessible" name="states" required tabindex="-1" aria-hidden="true">
                      <option selected="">Your States</option>
                    <option value="Goa">Goa</option></select><span class="select2 select2-container select2-container--default select2-container--below" dir="ltr" style="width: 270px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-states-container"><span class="select2-selection__rendered" id="select2-states-container" title="Goa">Goa</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="checkout-form-list">
                    <label>Postcode / Zip <span class="required">*</span></label>
                    <input placeholder="Postcode / Zip" name="pincode" type="text" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="country-select clearfix">
                    <label>Country <span class="required">*</span></label>
                    <input placeholder="Country" name="country" type="text" required>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="checkout-form-list create-acc">
                    <input id="cbox" name="create_account" type="checkbox">
                    <label>Create an account?</label>
                  </div>
                  <div id="cbox-info" class="checkout-form-list create-account" style="display: block;">
                    <p>Create an account by entering the information below. If you are a returning
                      customer please login at the top of the page.</p>
                    <label>Account password <span class="required">*</span></label>
                    <input placeholder="password" type="password">
                  </div>
                </div>
              </div>
                        <div class="different-address">
              <div class="ship-different-title">
                <h3>
                  <label>Ship to a different address?</label>
                  <input id="ship-box" type="checkbox">
                </h3>
              </div>
              <div id="ship-box-info" class="row">
                <div class="row">
                  <div class="col-md-6">
                    <div class="checkout-form-list">
                      <label>First Name <span class="required">*</span></label>
                      <input placeholder="" type="text" name="fname1" required>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="checkout-form-list">
                      <label>Last Name <span class="required">*</span></label>
                      <input placeholder="" type="text" name="lname1" required>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="checkout-form-list">
                      <label>Email Address <span class="required">*</span></label>
                      <input placeholder="" type="email" name="email1" required>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="checkout-form-list">
                      <label>Phone <span class="required">*</span></label>
                      <input type="text" name="mobile1" required>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="checkout-form-list">
                      <label>Address <span class="required">*</span></label>
                      <input placeholder="Street address" type="text" name="address1" required>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="checkout-form-list">
                      <input placeholder="Apartment, suite, unit etc. (optional)"  name="street1"   type="text" >
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="checkout-form-list">
                      <label>Town / City <span class="required">*</span></label>
                      <select class="form-control cities select2-hidden-accessible" name="city1" required tabindex="-1" aria-hidden="true">
                        <option selected="">Distributor City</option>
                      </select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-city-av-container"><span class="select2-selection__rendered" id="select2-city-av-container" title="Distributor City">Distributor City</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="checkout-form-list">
                      <label>State <span class="required">*</span></label>
                      <input placeholder="" type="text"  name="state1"  required>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="checkout-form-list">
                      <label>Postcode / Zip <span class="required">*</span></label>
                      <input placeholder="" type="text"  name="zip1"  required>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="myniceselect country-select clearfix">
                      <label>Country <span class="required">*</span></label>
                      <select class="nice-select myniceselect wide" style="display: none;"  name="country1"  required>
                        <option data-display="Bangladesh">Bangladesh</option>
                        <option value="uk">London</option>
                        <option value="rou">Romania</option>
                        <option value="fr">French</option>
                        <option value="de">Germany</option>
                        <option value="aus">Australia</option>
                      </select>
                      <div class="nice-select myniceselect wide" tabindex="0" style="display: none;"><span class="current">Bangladesh</span>
                        <ul class="list">
                          <li data-value="Bangladesh" data-display="Bangladesh" class="option selected">Bangladesh</li>
                          <li data-value="uk" class="option">London</li>
                          <li data-value="rou" class="option">Romania</li>
                          <li data-value="fr" class="option">French</li>
                          <li data-value="de" class="option">Germany</li>
                          <li data-value="aus" class="option">Australia</li>
                        </ul>
                      </div><div class="nice-select myniceselect wide" tabindex="0"><span class="current"></span><ul class="list"></ul></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="order-notes">
                <div class="checkout-form-list checkout-form-list-2">
                  <label>Order Notes</label>
                  <textarea id="checkout-mess" cols="30" rows="10" placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                </div>
              </div>
            </div>
          </div>
        </div>


        <div class="col-lg-6 col-12">
          <div class="your-order">
            <h3>Your order</h3>
            <div class="your-order-table table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th class="cart-product-name">Product</th>
                    <th class="cart-product-total">Total</th>
                  </tr>
                </thead>
                <tbody>
                                      <tr class="cart_item">
                      <td class="cart-product-name"> Zafar Azar Shirt<strong class="product-quantity">
                          × 1</strong>(Quantity)</td>
                      <td class="cart-product-total"><span class="amount">₹ 1,000.00 </span></td>
                                              <td class="cart-product-name"> size: S <strong class="product-quantity">
                                              </strong></td></tr>
                                  </tbody>
                <tfoot>
                  <tr class="cart-subtotal">
                    <th>Cart Subtotal</th>
                    <td><span class="amount">₹1,000.00</span></td>
                  </tr>
                  <tr class="order-total">
                    <th>Order Total</th>
                    <td><strong><span class="amount">₹1,000.00</span></strong></td>
                  </tr>
                </tfoot>
              </table>
            </div>
            <div class="payment-method">
              <div class="payment-accordion">
                <div id="accordion">
                  <div class="card">
                    <!--<div class="card-header" id="#payment-1">-->
                    <!--  <h5 class="panel-title">-->
                    <!--    <a href="javascript:void(0)" class="" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">-->
                    <!--      Direct Bank Transfer.-->
                    <!--    </a>-->
                    <!--  </h5>-->
                    <!--</div>-->

                  </div>
                  <div class="card">
                    <!--<div class="card-header" id="#payment-3">-->
                    <!--  <h5 class="panel-title">-->
                    <!--    <a href="javascript:void(0)" class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">-->
                    <!--      PayPal-->
                    <!--    </a>-->
                    <!--  </h5>-->
                    <!--</div>-->

                  </div>
                </div>
                <div class="order-button-payment">
                  <input value="Place order" type="submit">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>    <!-- </main> -->


    <!--Instagram Area End Here -->
    <!-- Begi Footer Area -->
<div class="kenne-footer_area bg-smoke_color">
  <div class="footer-top_area">
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="newsletter-area">
             <!--<div class="newsletter-logo">-->
             <!--                   <a href="javascript:void(0)">-->
             <!--                       <img src="http://localhost/tcom/assets/images/footer/logo/1.png" alt="Logo">-->
             <!--                   </a>-->
             <!--               </div> -->
            <p class="short-desc">Sign Up for Turaja Updates</p>
            <div class="newsletter-form_wrap">
              <form action="http://localhost/tcom/web/home/newsletter" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="newsletters-form validate">
                <div id="mc_embed_signup_scroll">
                  <div id="mc-form" class="mc-form subscribe-form">
                    <input id="mc-email" class="newsletter-input" type="email" name="email" autocomplete="off" placeholder="Enter email address" required>
                    <button type="submit" class="newsletter-btn" id="mc-submit"><i class="ion-android-mail"></i></button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-9 footer-right">
          <div class="row footer-widgets_wrap">
            <div class="col-lg-2 col-md-2 col-sm-2">
              <div class="footer-widgets social-icon">
                <ul>
                  <li><a href="javascript:void(0)"><i class="ion-social-facebook"></i></a></li>
                  <li><a href="javascript:void(0)"><i class="ion-social-instagram"></i></a></li>
                  <!--<li><a href="javascript:void(0)"><i class="ion-social-twitter"></i></a></li>-->
                </ul>
              </div>
            </div>

            <div class="col-lg-10 col-md-10 col-sm-10">
              <div class="footer-widgets quick-link">
                <ul>
                <li><a href="http://localhost/tcom/about">About Us</a></li>
                <li><a href="">Faq's </a></li>
                <li><a href="">Blog</a></li>
                <li><a href="http://localhost/tcom/privacy">Privacy Policy</a></li>
                <li><a href="http://localhost/tcom/term">Terms &amp; Conditions</a></li>
                <li><a href="http://localhost/tcom/refund">Refund/Exchange Policy</a></li>
                <li><a href="http://localhost/tcom/contact">Contact Us</a></li>
                </ul>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  </div>
  <div class="footer-bottom_area">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-6">
          <div class="copyright">
            <span>Copyright © 2020 <a href="">TURAJA.</a> All rights reserved.</span>
          </div>
        </div>
        <div class="col-md-6">
          <div class="payment">
            <img src="http://localhost/tcom/assets/images/footer/payment/1.png" alt="Kenne's Payment Method">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Footer Area End Here -->
    <!-- Begin Kenne's Modal Area -->
    <div class="modal fade modal-wrapper" id="exampleModalCenter">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
            <div class="modal-inner-area sp-area row">
              <div class="col-lg-5">
                <div class="sp-img_area">
                  <div class="kenne-element-carousel sp-img_slider slick-img-slider slick-carousel-0 slick-initialized slick-slider" data-slick-options="{
                                    &quot;slidesToShow&quot;: 1,
                                    &quot;arrows&quot;: false,
                                    &quot;fade&quot;: true,
                                    &quot;draggable&quot;: false,
                                    &quot;swipe&quot;: false,
                                    &quot;asNavFor&quot;: &quot;.sp-img_slider-nav&quot;
                                    }"><div class="slick-list draggable" style="height: 556px;"><div class="slick-track" style="opacity: 1; width: 3294px;"><div class="slick-slide slick-current slick-active first-active last-active" data-slick-index="0" aria-hidden="false" style="width: 549px; position: relative; left: 0px; top: 0px; z-index: 999; opacity: 1;"><div><div class="single-slide red" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/1-1.jpg" alt="Kenne's Product Image">
                    </div></div></div><div class="slick-slide" data-slick-index="1" aria-hidden="true" style="width: 549px; position: relative; left: -549px; top: 0px; z-index: 998; opacity: 0;" tabindex="-1"><div><div class="single-slide orange" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/1-2.jpg" alt="Kenne's Product Image">
                    </div></div></div><div class="slick-slide" data-slick-index="2" aria-hidden="true" style="width: 549px; position: relative; left: -1098px; top: 0px; z-index: 998; opacity: 0;" tabindex="-1"><div><div class="single-slide brown" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/2-1.jpg" alt="Kenne's Product Image">
                    </div></div></div><div class="slick-slide" data-slick-index="3" aria-hidden="true" style="width: 549px; position: relative; left: -1647px; top: 0px; z-index: 998; opacity: 0;" tabindex="-1"><div><div class="single-slide umber" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/2-2.jpg" alt="Kenne's Product Image">
                    </div></div></div><div class="slick-slide" data-slick-index="4" aria-hidden="true" style="width: 549px; position: relative; left: -2196px; top: 0px; z-index: 998; opacity: 0;" tabindex="-1"><div><div class="single-slide black" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/3-1.jpg" alt="Kenne's Product Image">
                    </div></div></div><div class="slick-slide" data-slick-index="5" aria-hidden="true" style="width: 549px; position: relative; left: -2745px; top: 0px; z-index: 998; opacity: 0;" tabindex="-1"><div><div class="single-slide golden" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/3-2.jpg" alt="Kenne's Product Image">
                    </div></div></div></div></div></div>
                  <div class="kenne-element-carousel sp-img_slider-nav arrow-style-2 arrow-style-3 slick-carousel-1 slick-gutter-30 slick-initialized slick-slider" data-slick-options="{
                                   &quot;slidesToShow&quot;: 4,
                                    &quot;asNavFor&quot;: &quot;.sp-img_slider&quot;,
                                   &quot;focusOnSelect&quot;: true,
                                   &quot;arrows&quot; : true,
                                   &quot;spaceBetween&quot;: 30
                                  }" data-slick-responsive="[
                                    {&quot;breakpoint&quot;:1501, &quot;settings&quot;: {&quot;slidesToShow&quot;: 3}},
                                    {&quot;breakpoint&quot;:1200, &quot;settings&quot;: {&quot;slidesToShow&quot;: 2}},
                                    {&quot;breakpoint&quot;:992, &quot;settings&quot;: {&quot;slidesToShow&quot;: 4}},
                                    {&quot;breakpoint&quot;:768, &quot;settings&quot;: {&quot;slidesToShow&quot;: 3}},
                                    {&quot;breakpoint&quot;:575, &quot;settings&quot;: {&quot;slidesToShow&quot;: 2}}
                                ]"><button class="tty-slick-text-btn tty-slick-text-prev slick-arrow slick-disabled" aria-disabled="true" style="display: block;"><i class="ion-ios-arrow-back"></i></button><div class="slick-list draggable"><div class="slick-track" style="opacity: 1; width: 696px; transform: translate3d(0px, 0px, 0px);"><div class="slick-slide slick-current slick-active first-active" data-slick-index="0" aria-hidden="false" style="width: 116px;"><div><div class="single-slide red" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/1-1.jpg" alt="Kenne's Product Thumnail">
                    </div></div></div><div class="slick-slide slick-active" data-slick-index="1" aria-hidden="false" style="width: 116px;"><div><div class="single-slide orange" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/1-2.jpg" alt="Kenne's Product Thumnail">
                    </div></div></div><div class="slick-slide slick-active" data-slick-index="2" aria-hidden="false" style="width: 116px;"><div><div class="single-slide brown" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/2-1.jpg" alt="Kenne's Product Thumnail">
                    </div></div></div><div class="slick-slide slick-active last-active" data-slick-index="3" aria-hidden="false" style="width: 116px;"><div><div class="single-slide umber" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/2-2.jpg" alt="Kenne's Product Thumnail">
                    </div></div></div><div class="slick-slide" data-slick-index="4" aria-hidden="true" style="width: 116px;" tabindex="-1"><div><div class="single-slide black" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/3-1.jpg" alt="Kenne's Product Thumnail">
                    </div></div></div><div class="slick-slide" data-slick-index="5" aria-hidden="true" style="width: 116px;" tabindex="-1"><div><div class="single-slide golden" style="width: 100%; display: inline-block;">
                      <img src="http://localhost/tcom/assets/images/product/3-2.jpg" alt="Kenne's Product Thumnail">
                    </div></div></div></div></div><button class="tty-slick-text-btn tty-slick-text-next slick-arrow" style="display: block;" aria-disabled="false"><i class="ion-ios-arrow-forward"></i></button></div>
                </div>
              </div>
              <div class="col-xl-7 col-lg-6">
                <div class="sp-content">
                  <div class="sp-heading">
                    <h5><a href="#">Dolorem odio provident ut nihil</a></h5>
                  </div>
                  <div class="rating-box">
                    <ul>
                      <li><i class="ion-android-star"></i></li>
                      <li><i class="ion-android-star"></i></li>
                      <li><i class="ion-android-star"></i></li>
                      <li class="silver-color"><i class="ion-android-star"></i></li>
                      <li class="silver-color"><i class="ion-android-star"></i></li>
                    </ul>
                  </div>
                  <div class="price-box">
                    <span class="new-price new-price-2">Rs.194.00</span>
                    <span class="old-price">Rs.241.00</span>
                  </div>
                  <div class="sp-essential_stuff">
                    <ul>
                      <li>Brands <a href="javascript:void(0)">Buxton</a></li>
                      <li>Product Code: <a href="javascript:void(0)">Product 16</a></li>
                      <li>Reward Points: <a href="javascript:void(0)">100</a></li>
                      <li>Availability: <a href="javascript:void(0)">In Stock</a></li>
                      <li>EX Tax: <a href="javascript:void(0)"><span>Rs.453.35</span></a></li>
                      <li>Price in reward points: <a href="javascript:void(0)">400</a></li>
                    </ul>
                  </div>
                  <div class="color-list_area">
                    <div class="color-list_heading">
                      <h4>Available Options</h4>
                    </div>
                    <span class="sub-title">Color</span>
                    <div class="color-list">
                      <a href="javascript:void(0)" class="single-color active" data-swatch-color="red">
                        <span class="bg-red_color"></span>
                        <span class="color-text">Red (+Rs.150)</span>
                      </a>
                      <a href="javascript:void(0)" class="single-color" data-swatch-color="orange">
                        <span class="burnt-orange_color"></span>
                        <span class="color-text">Orange (+Rs.170)</span>
                      </a>
                      <a href="javascript:void(0)" class="single-color" data-swatch-color="brown">
                        <span class="brown_color"></span>
                        <span class="color-text">Brown (+Rs.120)</span>
                      </a>
                      <a href="javascript:void(0)" class="single-color" data-swatch-color="umber">
                        <span class="raw-umber_color"></span>
                        <span class="color-text">Umber (+Rs.125)</span>
                      </a>
                      <a href="javascript:void(0)" class="single-color" data-swatch-color="black">
                        <span class="black_color"></span>
                        <span class="color-text">Black (+Rs.125)</span>
                      </a>
                      <a href="javascript:void(0)" class="single-color" data-swatch-color="golden">
                        <span class="golden_color"></span>
                        <span class="color-text">Golden (+Rs.125)</span>
                      </a>
                    </div>
                  </div>
                  <div class="quantity">
                    <label>Quantity</label>
                    <div class="cart-plus-minus">
                      <input class="cart-plus-minus-box" value="1" type="text">
                      <div class="dec qtybutton"><i class="fa fa-angle-down"></i></div>
                      <div class="inc qtybutton"><i class="fa fa-angle-up"></i></div>
                    <div class="dec qtybutton"><i class="fa fa-angle-down"></i></div><div class="inc qtybutton"><i class="fa fa-angle-up"></i></div></div>
                  </div>
                  <div class="kenne-group_btn">
                    <ul>
                      <li><a href="cart.html" class="add-to_cart">Cart To Cart</a></li>
                      <li><a href="cart.html"><i class="ion-android-favorite-outline"></i></a></li>
                      <li><a href="cart.html"><i class="ion-ios-shuffle-strong"></i></a></li>
                    </ul>
                  </div>
                  <div class="kenne-tag-line">
                    <h6>Tags:</h6>
                    <a href="javascript:void(0)">Scraf</a>,
                    <a href="javascript:void(0)">hoodie</a>,
                    <a href="javascript:void(0)">jacket</a>
                  </div>
                  <div class="kenne-social_link">
                    <ul>
                      <li class="facebook">
                        <a href="https://www.facebook.com" data-toggle="tooltip" target="_blank" title="" data-original-title="Facebook">
                          <i class="fab fa-facebook"></i>
                        </a>
                      </li>
                      <li class="twitter">
                        <a href="https://twitter.com" data-toggle="tooltip" target="_blank" title="" data-original-title="Twitter">
                          <i class="fab fa-twitter-square"></i>
                        </a>
                      </li>
                      <li class="youtube">
                        <a href="https://www.youtube.com" data-toggle="tooltip" target="_blank" title="" data-original-title="Youtube">
                          <i class="fab fa-youtube"></i>
                        </a>
                      </li>
                      <li class="google-plus">
                        <a href="https://www.plus.google.com/discover" data-toggle="tooltip" target="_blank" title="" data-original-title="Google Plus">
                          <i class="fab fa-google-plus"></i>
                        </a>
                      </li>
                      <li class="instagram">
                        <a href="https://rss.com" data-toggle="tooltip" target="_blank" title="" data-original-title="Instagram">
                          <i class="fab fa-instagram"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Kenne's Modal Area End Here -->
    <!-- Scroll To Top Start -->
    <a class="scroll-to-top" href=""><i class="ion-chevron-up"></i></a>
    <!-- Scroll To Top End -->
    <a href="#" class="wfloat" target="_blank"><i class="fa fa-whatsapp my-float"></i></a>
  </div>
  
  <!-- JS
============================================ -->
  <!-- Modernizer JS -->
  <script src="http://localhost/tcom/assets/js/vendor/modernizr-2.8.3.min.js"></script>
  <!-- Popper JS -->
  <script src="http://localhost/tcom/assets/js/vendor/popper.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="http://localhost/tcom/assets/js/vendor/bootstrap.min.js"></script>

  <!-- Slick Slider JS -->
  <script src="http://localhost/tcom/assets/js/plugins/slick.min.js"></script>
  <!-- Barrating JS -->
  <script src="http://localhost/tcom/assets/js/plugins/jquery.barrating.min.js"></script>
  <!-- Counterup JS -->
  <script src="http://localhost/tcom/assets/js/plugins/jquery.counterup.js"></script>
  <!-- Nice Select JS -->
  <script src="http://localhost/tcom/assets/js/plugins/jquery.nice-select.js"></script>
  <!-- Sticky Sidebar JS -->
  <script src="http://localhost/tcom/assets/js/plugins/jquery.sticky-sidebar.js"></script>
  <!-- Jquery-ui JS -->
  <script src="http://localhost/tcom/assets/js/plugins/jquery-ui.min.js"></script>
  <script src="http://localhost/tcom/assets/js/plugins/jquery.ui.touch-punch.min.js"></script>
  <!-- Theia Sticky Sidebar JS -->
  <script src="http://localhost/tcom/assets/js/plugins/theia-sticky-sidebar.min.js"></script>
  <!-- Waypoints JS -->
  <script src="http://localhost/tcom/assets/js/plugins/waypoints.min.js"></script>
  <!-- jQuery Zoom JS -->
  <script src="http://localhost/tcom/assets/js/plugins/jquery.zoom.min.js"></script>
  <!-- Timecircles JS -->
  <script src="http://localhost/tcom/assets/js/plugins/timecircles.js"></script>

  <script src="http://localhost/tcom/assets/select2/select2.js"></script>


  <!-- Vendor & Plugins JS (Please remove the comment from below vendor.min.js & plugins.min.js for better website load performance and remove js files from avobe) -->
  <!--
<script src="http://localhost/tcom/assets/js/vendor/vendor.min.js"></script>
<script src="http://localhost/tcom/assets/js/plugins/plugins.min.js"></script> -->

  <!-- Main JS -->
  <script src="http://localhost/tcom/assets/js/main.js"></script>

  <!-- GetButton.io widget -->

  <!-- /GetButton.io widget -->

  <script type="text/javascript">
  $(document).ready(function(){
    $('.lbl').click(function(){

    window.size = $(this).text();


    });
    var miniCart = $('#miniCart');
    var itemCount = $('.card-item-count');
    $(document).on('click', '.minicart', function(){

      var pid = $(this).attr('data-id');
    var qty = $("#qty").val(); var unit = $("#unit").text();
        miniCart.addClass('open');


      $.ajax({
          url : "http://localhost/tcom/web/collection/addtocard",
          method : "POST",
          data : {pid: pid, qty: qty,unit: unit,size: window.size},
          success: function(data) {
            cart_view();
          }
      });
    });



    function cart_view() {
      $.ajax({
          url: "http://localhost/tcom/web/collection/miniCart",
          method: "GET",
          success: function(data) {
            cart_count();
            miniCart.html(data);

          }
      });
    }
    function cart_count() {
      $.ajax({
          url: "http://localhost/tcom/web/collection/cart_count",
          method: "GET",
          success: function(data) {
            itemCount.html(data);
          }
      });
    }


    cart_view();
  });
</script>
  <script type="text/javascript">
  $(document).ready(function(){
      // Select cities list
      

    $('.cities').select2({
      ajax: {
         url: 'http://localhost/tcom/cities',
         type: "GET",
         dataType: 'json',
         data: function (params) {
           var query = {
             search: params.term,
             type: 'public',
             "ci_csrf_token": "",
           }
           return query;
         },
         processResults: function (data) {
            return {
              results: data
            };
          },
         // Additional AJAX parameters go here; see the end of this chapter for the full code of this example
       }
    });
    // Select states list
    $('#states').select2({
      ajax: {
         url: 'http://localhost/tcom/states',
         type: "GET",
         dataType: 'json',
         data: function (params) {
           var query = {
             search: params.term,
             type: 'public',
             "ci_csrf_token": "",
           }
           return query;
         },
         processResults: function (data) {
            return {
              results: data
            };
          },
         // Additional AJAX parameters go here; see the end of this chapter for the full code of this example
       }
    });
  });
</script>

  



</body>