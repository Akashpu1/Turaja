<div class="contact-main-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 order-1 order-lg-2">
              <p style="color:red;Font-weight:bold;align-center;"> Paymment success</p>
            </div>
        </div>
    </div>
</div>
