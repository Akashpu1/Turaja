<!-- Begin Kenne's Breadcrumb Area -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="breadcrumb-content">
            <h2>Return & Cancellations</h2>
         
        </div>
    </div>
</div>
<!--  Breadcrumb Area End Here -->
<!-- BeginAbout Us Area -->
<div class="about-us-area">
    <div class="container">
        <div class="row">
            
            <div class="col-lg-12 col-md-12 d-flex align-items-center">
                <div class="overview-content">
            <p>    RETURN POLICY Returns will only be accepted in case of a manufacturing defect or dispatch of incorrect items. </p>
<p> No returns will be accepted if the product falls under the Special Price section.  - Please note, our fabrics are pure and each saree requires very care in handling. </p>
<p><b>   Your return request should be informed only through email to  info@turaja.com within 24 hours of receiving the shipment with corresponding images of the defect. </b></p>

<ol class="list-2">
<li>Hence, we offer returns only in extreme circumstances. </li>
<li> Saree cannot be Returnd / exchanged if fall Pico is done or Blouse is detached.  Saree (s) can be returned / exchanged within 24 hours from the date of delivery subject to A customer returning the saree unused, unwashed, unaltered and its original condition with all tags intact.</li>
<li> The original invoice must be produced at the time of the request for exchange.  We do not accept packages from any courier other than Blue Dart. </li>
<li>The company reserves the right to decide if the saree is in the condition for exchange and such decision of company shall be final and binding.</li>
<li> If you receive a package that appears to have been tempered, you are advised not to accept such parcel and DON'T open the package.</li>
<li> Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. </li>
<li>    We will also notify you of the approval or rejection of your refund.  If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit / debit card or your bank account. </li>
<li>   In case of a Wallet refund, the full amount of the order shall be added to the Wallet for future purchases. </li>
<!-- <li>Our delivery representatives from your country will come to pick up the goods along with the papers we will send via email once a return request is made, we insist you keep the items properly packed for the pickup. In the rare instance that we’re unable to send a representative to your assigned address, you may have to drop the package to a local post office.</li>
<li>Please follow our return guidelines, Turaja cannot be held liable for the loss of garments being returned independently, we recommend that you use our registered shipping method so that the order can be tracked.</li> -->

</ol>


                    
                </div>
            </div>
        </div>
    </div>
</div>
<!--  About Us Area End Here -->