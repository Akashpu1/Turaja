<?php get_section('layout/css'); ?>
<div class="main-wrapper">


    <!-- <header> -->
    <?php get_section('layout/header'); ?>
    <!-- </header> -->
    

    <!-- <main> -->
    <?php echo $main_content;  ?>
    <!-- </main> -->


    <!--Instagram Area End Here -->
    <?php get_section('layout/footer'); ?>
    <!-- Begin Kenne's Modal Area -->
    
    <!-- Kenne's Modal Area End Here -->
    <!-- Scroll To Top Start -->
    <a class="scroll-to-top" href=""><i class="ion-chevron-up"></i></a>
    <!-- Scroll To Top End -->
    <a href="#" class="wfloat" target="_blank"><i class="fa fa-whatsapp my-float"></i></a>
  </div>
  <?php get_section('layout/script'); ?>
