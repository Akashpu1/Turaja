<div class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="card card-user">
        <div class="card-body text-center">
          <h2> <p class="text-danger"> Thank You</p> </h2><p class="text-danger" style="color:green;"> <br> <?php echo  $massege; ?></p> 
          <a href="<?php echo base_url('web/home'); ?>"><button  type="button" class="btn btn-lg  btn-fill" name="button"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> Back Home</button></a>
        </div>
        <div class="card-footer">
            <hr>
            <div class="stats">
              <p class="text-danger"> <i class="fa fa-exclamation"></i> don't Reload this page</p>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
