<!-- JS
============================================ -->

<!-- jQuery JS -->
<script src="<?php echo base_url() ?>/assets/js/vendor/jquery-3.3.1.min.js"></script>

<!-- Modernizer JS -->
<script src="<?php echo base_url() ?>/assets/js/vendor/modernizr-3.6.0.min.js"></script>
<!-- Popper JS -->
<script src="<?php echo base_url() ?>/assets/js/vendor/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="<?php echo base_url() ?>/assets/js/vendor/bootstrap.min.js"></script>
<!-- slick Slider JS -->
<script src="<?php echo base_url() ?>/assets/js/plugins/slick.min.js"></script>
<!-- Countdown JS -->
<script src="<?php echo base_url() ?>/assets/js/plugins/countdown.min.js"></script>
<!-- Nice Select JS -->
<script src="<?php echo base_url() ?>/assets/js/plugins/nice-select.min.js"></script>
<!-- jquery UI JS -->
<script src="<?php echo base_url() ?>/assets/js/plugins/jqueryui.min.js"></script>
<!-- Image zoom JS -->
<script src="<?php echo base_url() ?>/assets/js/plugins/image-zoom.min.js"></script>
<!-- Imagesloaded JS -->
<script src="<?php echo base_url() ?>/assets/js/plugins/imagesloaded.pkgd.min.js"></script>
<!-- Instagram feed JS -->
<script src="<?php echo base_url() ?>/assets/js/plugins/instagramfeed.min.js"></script>
<!-- mailchimp active js -->
<script src="<?php echo base_url() ?>/assets/js/plugins/ajaxchimp.js"></script>
<!-- contact form dynamic js -->
<script src="<?php echo base_url() ?>/assets/js/plugins/ajax-mail.js"></script>
<!-- google map api -->
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCfmCVTjRI007pC1Yk2o2d_EhgkjTsFVN8"></script> -->
<!-- google map active js -->
<script src="<?php echo base_url() ?>/assets/js/plugins/google-map.js"></script>
<!-- Main JS -->
<script src="<?php echo base_url() ?>/assets/js/main.js"></script>

</html>
