<!-- JavaScript -->

  <!-- jQuery -->
  <script src="<?php echo base_url(); ?>/vendors/bower_components/jquery/dist/jquery.min.js"></script>

  <!-- Bootstrap Core JavaScript -->
  <script src="<?php echo base_url(); ?>/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

  <script src="<?php echo base_url(); ?>/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url(); ?>dist/js/dataTables-data.js"></script>

<!-- Slimscroll JavaScript -->
<script src="<?php echo base_url('optimum'); ?>/dist/js/jquery.slimscroll.js"></script>

<!-- simpleWeather JavaScript -->
<script src="<?php echo base_url(); ?>vendors/bower_components/moment/min/moment.min.js"></script>
<!-- Fancy Dropdown JS -->
<script src="<?php echo base_url('optimum'); ?>/dist/js/dropdown-bootstrap-extended.js"></script>

<!-- Owl JavaScript -->
<script src="<?php echo base_url(); ?>vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>

<!-- Switchery JavaScript -->
<script src="<?php echo base_url(); ?>vendors/bower_components/switchery/dist/switchery.min.js"></script>
<script src="<?php echo base_url(); ?>vendors/bower_components/dropify/dist/js/dropify.min.js"></script>

<!-- Form Flie Upload Data JavaScript -->
<script src="<?php echo base_url('optimum'); ?>/dist/js/form-file-upload-data.js"></script>
<!-- Dropzone JavaScript -->
<script src="<?php echo base_url(); ?>vendors/bower_components/dropzone/dist/dropzone.js"></script>
<!-- Progressbar Animation JavaScript -->
<script src="<?php echo base_url('optimum'); ?>/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url('optimum'); ?>/vendors/bower_components/jquery.counterup/jquery.counterup.min.js"></script>

		<!-- Dropzone Init JavaScript -->
<!-- Bootstrap Select JavaScript -->
<script src="<?php echo base_url(); ?>vendors/bower_components/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<!-- Gallery JavaScript -->
  <script src="<?php echo base_url(); ?>optimum/dist/js/isotope.js"></script>
  <script src="<?php echo base_url(); ?>optimum/dist/js/lightgallery-all.js"></script>
  <script src="<?php echo base_url(); ?>optimum/dist/js/froogaloop2.min.js"></script>
  <script src="<?php echo base_url(); ?>optimum/dist/js/gallery-data.js"></script>
<!-- Summernote Plugin JavaScript -->
		<script src="<?php echo base_url(); ?>/vendors/bower_components/summernote/dist/summernote.min.js"></script>
	<!-- Summernote Wysuhtml5 Init JavaScript -->
		<script src="<?php echo base_url('optimum'); ?>/dist/js/summernote-data.js"></script>
   <!-- Multiselect JavaScript -->
		<script src="<?php echo base_url(); ?>vendors/bower_components/multiselect/js/jquery.multi-select.js"></script>
   <!-- Bootstrap Select JavaScript -->
		<script src="<?php echo base_url(); ?>vendors/bower_components/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
			<!-- Select2 JavaScript -->
		<script src="<?php echo base_url(); ?>vendors/bower_components/select2/dist/js/select2.full.min.js"></script>
	<!-- Bootstrap Tagsinput JavaScript -->
		<script src="<?php echo base_url(); ?>vendors/bower_components/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<!-- Bootstrap Touchspin JavaScript -->
		<script src="<?php echo base_url(); ?>vendors/bower_components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js"></script>
<!-- Slimscroll JavaScript -->
		<script src="<?php echo base_url('optimum'); ?>/dist/js/jquery.slimscroll.js"></script>

		<!-- Fancy Dropdown JS -->
		<script src="<?php echo base_url('optimum'); ?>/dist/js/dropdown-bootstrap-extended.js"></script>

		<!-- Owl JavaScript -->
		<script src="<?php echo base_url(); ?>vendors/bower_components/owl.carousel/dist/owl.carousel.min.js"></script>
	<!-- Bootstrap Switch JavaScript -->
		<script src="<?php echo base_url(); ?>vendors/bower_components/bootstrap-switch/dist/js/bootstrap-switch.min.js"></script>
		<!-- Switchery JavaScript -->
		<script src="<?php echo base_url(); ?>vendors/bower_components/switchery/dist/switchery.min.js"></script>
<!-- Init JavaScript -->
<script id='mapData' src="<?php echo base_url('optimum'); ?>/dist/js/init.js"></script>
<!-- <script src="<?php echo base_url('optimum'); ?>/dist/js/ecommerce-data.js"></script> -->
<!-- Form Advance Init JavaScript -->
		<script src="<?php echo base_url('optimum'); ?>/dist/js/form-advance-data.js"></script>
    <script src="<?php echo base_url('optimum'); ?>/dist/js/dropzone-data.js"></script>

    <?php include("__media.php"); ?>
    <?php include("__notification.php"); ?>
</body>

</html>
