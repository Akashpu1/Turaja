<script>
$(document).ready(function(){
	function getresult(url) {
		$.ajax({
			url: url,
			type: "GET",
			data:  {rowcount:$("#rowcount").val()},
			beforeSend: function(){
			$('#loader-icon').show();
			},
			complete: function(){
			$('#loader-icon').hide();
			},
			success: function(data){
			$("#product-list").append(data);
			},
			error: function(){}
	   });
	}
	<?php if (isset($cat) && !empty($cat)) { ?>
		// code...
		getresult('load?cat=<?php echo $cat; ?>&page=1');
		<?php	}else { ?>
		getresult('load?page=1');
	<?php	} ?>
	$(window).scroll(function(){
		if ($(window).scrollTop() == $(document).height() - $(window).height()){
			if($(".pagenum:last").val() <= $(".total-page").val()) {
				var pagenum = parseInt($(".pagenum:last").val()) + 1;
				<?php if (isset($cat) && !empty($cat)) { ?>
					getresult('load?cat=<?php echo $cat; ?>&page='+pagenum);
					<?php	}else { ?>
						getresult('load?page='+pagenum);
				<?php	} ?>
			}
		}
	});
});
</script>
