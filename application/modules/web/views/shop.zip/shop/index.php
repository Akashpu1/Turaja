<?php// pre($product); ?>
<!-- Begin Kenne's Content Wrapper Area -->
<div class="kenne-content_wrapper">
  <div class="container">
    <div class="row">
      <div class="col-lg-3 order-2 order-lg-1">
        <div class="kenne-sidebar-catagories_area">
          <div class="kenne-sidebar_categories">
            <div class="kenne-categories_title first-child">
              <h5>Filter by price</h5>
            </div>
            <div class="price-filter">
              <div id="slider-range"></div>
              <div class="price-slider-amount">
                <div class="label-input">
                  <label>price : </label>
                  <input type="text" id="amount" name="price" placeholder="Add Your Price" />
                  <button class="filter-btn">Filter</button>
                </div>
              </div>
            </div>
          </div>
          <div class="kenne-sidebar_categories category-module">
            <div class="kenne-categories_title">
              <h5>Craft</h5>
            </div>
            <div class="sidebar-categories_menu">
              <ul>


                <li><a href="javascript:void(0)">View All</a></li>
                <li><a href="javascript:void(0)">Embroidery</a></li>
                <li><a href="javascript:void(0)">Printed </a></li>
                <li><a href="javascript:void(0)">Woven Dyed </a></li>






              </ul>
            </div>
          </div>
          <div class="kenne-sidebar_categories">
            <div class="kenne-categories_title">
              <h5>Color</h5>
            </div>
            <ul class="sidebar-checkbox_list">
              <li>
                <a href="javascript:void(0)">Black (1)</a>
              </li>
              <li>
                <a href="javascript:void(0)">Blue (1)</a>
              </li>
              <li>
                <a href="javascript:void(0)">Gold (3)</a>
              </li>
            </ul>
          </div>

        </div>
      </div>
      <div class="col-lg-9 order-1 order-lg-2">
        <div class="shop-toolbar">
          <div class="product-view-mode">
            <a class="active grid-3" data-target="gridview-3" data-toggle="tooltip" data-placement="top" title="Grid View"><i class="fa fa-th"></i></a>
            <!--<a class="active list" data-target="listview" data-toggle="tooltip" data-placement="top" title="List View"><i class="fa fa-th-list"></i></a>-->
          </div>
          <div class="product-page_count">
            <p>Showing 1–9 of <?php echo $listCount; ?> results</p>
          </div>
          <div class="product-item-selection_area">
            <div class="product-short">
              <label class="select-label">Short By:</label>
              <select class="nice-select myniceselect">
                <option value="1">Recommended</option>
                <option value="2">Name, A to Z</option>
                <option value="3">Name, Z to A</option>
                <option value="4">Price, low to high</option>
                <option value="5">Price, high to low</option>
              </select>
            </div>
          </div>
        </div>
        <div class="shop-product-wrap grid gridview-3 row" id="product-list"></div>
        <div id="loader-icon"><img src="<?php echo base_url('assets/images/loaderIcon.gif'); ?>"></div>
      </div>
    </div>
  </div>
</div>
<!-- Kenne's Content Wrapper Area End Here -->
